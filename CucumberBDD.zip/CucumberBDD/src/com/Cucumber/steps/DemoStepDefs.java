package com.Cucumber.steps;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DemoStepDefs {
	
	@Given("^I launch the url \"([^\"]*)\"$")
	public void i_launch_the_url(String arg1) throws Throwable {
	  
	}

	@When("^I enter password and username$")
	public void i_enter_password_and_username() throws Throwable {
	   
	}

	@When("^I click on login button$")
	public void i_click_on_login_button() throws Throwable {
	   
	}

	@Then("^I should see the Home Page$")
	public void i_should_see_the_Home_Page() throws Throwable {
	    
	}

}
