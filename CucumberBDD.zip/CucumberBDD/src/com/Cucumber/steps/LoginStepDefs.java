package com.Cucumber.steps;


import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;


import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefs {

	WebDriver driver;

	@Given("^I am in the login page of the application$")
	public void i_am_in_the_login_page_of_the_application() throws Throwable {
		System.setProperty("webdriver.ie.driver", "D:\\Abhishek\\driver\\IEDriverServer.exe");
		driver = new InternetExplorerDriver();
		driver.get("http://newtours.demoaut.com/");
	}

	@When("^I login using the invalid username \"([^\"]*)\" and the invalid password \"([^\"]*)\"$")
	public void i_login_using_the_invalid_username_and_the_invalid_password(String userName, String password) throws Throwable {
		login(userName, password);
	}

	@Then("^The application should stay on the login page, and not log me in$")
	public void the_application_should_stay_on_the_login_page_and_not_log_me_in() throws Throwable {
		driver.quit();
	}

	@When("^I login using the valid username \"([^\"]*)\" and the valid password \"([^\"]*)\"$")
	public void i_login_using_the_valid_username_and_the_valid_password(String userName, String password) throws Throwable {
		login(userName, password);
	}

	@Then("^The application should log me in and navigate to the Flight Finder page$")
	public void the_application_should_log_me_in_and_navigate_to_the_Flight_Finder_page() throws Throwable {
	   driver.quit();
	}
	
	public void login(String userName, String password) {
		driver.findElement(By.name("userName")).sendKeys(userName);
		driver.findElement(By.name("password")).sendKeys(password);
		driver.findElement(By.name("login")).click();
	}
	
	@When("^I register a new user with the following details:$")
	public void registerUser(DataTable userData) {
		Map<String, String> newUser = userData.asMap(String.class, String.class);
		
		driver.findElement(By.linkText("REGISTER")).click();
		driver.findElement(By.name("firstName")).sendKeys(newUser.get("FirstName"));
		driver.findElement(By.name("lastName")).sendKeys(newUser.get("LastName"));		
		driver.findElement(By.name("phone")).sendKeys(newUser.get("Phone"));		
		driver.findElement(By.name("userName")).sendKeys(newUser.get("Email"));	
		driver.findElement(By.name("address1")).sendKeys(newUser.get("Address"));
		driver.findElement(By.name("city")).sendKeys(newUser.get("City"));
		driver.findElement(By.name("state")).sendKeys(newUser.get("State"));
		driver.findElement(By.name("postalCode")).sendKeys(newUser.get("PostalCode"));
		driver.findElement(By.name("email")).sendKeys(newUser.get("Username"));
		driver.findElement(By.name("password")).sendKeys(newUser.get("Password"));
		driver.findElement(By.name("confirmPassword")).sendKeys(newUser.get("Password"));
	
		driver.findElement(By.name("register")).click();
	}
	
}
